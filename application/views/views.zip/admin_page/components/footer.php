<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Phiên bản</b> <a href="https://github.com/ngthuc/khubaoton/archive/<?php echo  get_system('default','version'); ?>.zip"><?php echo  get_system('default','version'); ?></a>
  </div>
  <strong>Bản quyền &copy; 2018 <a href="https://ngthuc.com/">Nguyên Thức</a>.</strong> Quyền sở hữu thuộc về <a href="<?php echo  get_system('default','url'); ?>"><?php echo  get_system('default','site_name'); ?></a>
</footer>

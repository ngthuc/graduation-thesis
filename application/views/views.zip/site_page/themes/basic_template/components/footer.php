<div class="border footer" id="footer">
    <table id="tb_footer"><tbody><tr>
        <!-- <td>Last update May 2018</td> -->
        <td>Can Tho University, College of ICT</td>
    </tr></tbody></table>
</div>

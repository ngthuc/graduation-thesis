<link rel="stylesheet" type="text/css" href="<?=base_url('public/themes/basic_template/css/format.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?=base_url('public/themes/basic_template/css/cv1.css'); ?>">
